#!/bin/bash

echo "pluginuninstallend"